

#' @importFrom stats na.omit setNames
#' @importFrom utils available.packages contrib.url file_test formatUL getFromNamespace glob2rx packageVersion read.csv
NULL
